//
//  AppDelegate.h
//  video
//
//  Created by 123 on 2018/10/18.
//  Copyright © 2018 123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

