//
//  ViewController.m
//  video
//
//  Created by 123 on 2018/10/18.
//  Copyright © 2018 123. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic,strong) MPMoviePlayerController *moviePlayer;//视频播放控制器

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    -(NSURL *)getNetworkUrl{
        NSString *urlStr=@"http://192.168.1.161/The New Look of OS X Yosemite.mp4";
        urlStr=[urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:urlStr];
        return url;
    }
    
   /* NSURL *url = [NSURL URLWithString:@"http://pl.youku.com/playlist/m3u8?vid=174867986&type=mp4&ts=1397812170&keyframe=0&ep=ciGdHUGMVM8G7CLbij8bNiWzdiEHXP8N8heDhttqBtQnTey8&sid=039781216914212a9a2f8&token=3543&ctype=12&ev=1&oip=1876824509"];
  //  NSURL *url=[NSURL fileURLWithPath:file];
    movie =[[MPMoviePlayerController alloc]initWithContentURL:url];
    [movie.view setFrame:vv.frame];
    [self.view addSubview:movie.view];
    
}*/


- (IBAction)pause:(id)sender {[movie stop];
}

- (IBAction)play:(id)sender {[movie play];
}
@end
