//
//  ViewController.h
//  video
//
//  Created by 123 on 2018/10/18.
//  Copyright © 2018 123. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@interface ViewController : UIViewController{
IBOutlet UIView *vv;
    MPMoviePlayerController *movie;
}
- (IBAction)pause:(id)sender;
- (IBAction)play:(id)sender;
@property (nonatomic, copy) NSURL *contentURL;
@property (nonatomic, copy) NSString   *title;
- (instancetype)initWithContentURL:(NSURL *)url;
-（NSURL *)getNetworkUrl;
@end

